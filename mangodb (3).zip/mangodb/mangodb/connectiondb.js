module.exports={
    // url:'mongodb+srv://201fa04055:vanitha2003@cluster0.suyfqna.mongodb.net/?retryWrites=true&w=majority'
    url: 'mongodb://127.0.0.1:27017/student_db'
}
